def reverseStr(str):
    if (len(str) % 4) == 0:
        print(str[::-1])


reverseStr(input('Exter string => '))
