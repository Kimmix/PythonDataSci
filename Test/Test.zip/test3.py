x = input('Enter string => ')
f = input('String to find =>')
if (str(x)[0] == f):
    print('Found specified')
else:
    print('Not found')
