x = input('Exter string => ')
print(len(x))
